import pyArduino

# if __name__ == '__main__':
    
    # # 1st instanciate the ShowConnectionInfo Class, which autoconnect your board via Serial
    # #due to inheritance properties, and will give you a full review of your board capabilities.
    # info = pyArduino.ShowConnectionInfo()

    # # This 'show_info()' method gives you back basic info about the status
    # info.show_info()

    # # Shows you current layout config of your board
    # info.board_config()

    # # if you need to get for your software how many pins you have without hardcoring the number  
    # total_pins = info.board_number_pins()
    # print(total_pins)


    #NOTE Copy paste this onto your cwd with your .py file, do not use this example from ./examples.example.py