from pyArduino.lcd_control import LCD

# if __name__ == '__main__':

#     try:
#         my_lcd = LCD()
#         my_lcd.lcd_init()

#     except KeyboardInterrupt:

#         pass

#     finally:

#         my_lcd.lcd_write("TEXT1",LCD.SCREEN_LINE_1)
#         my_lcd.lcd_write("TEXT2",LCD.SCREEN_LINE_2)


# NOTE Copy paste this onto your cwd on your main.py file, do not use this example from ./examples.lcd_example.py